package com.example.parcialjg;

import android.os.Bundle;
import android.view.MenuItem;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import android.os.Bundle;
import android.view.MenuItem;

public class SegundaActivity extends AppCompatActivity {

    BottomNavigationView bto_navigation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bto_navigation = findViewById(R.id.bto_navigation);

        loadFragment(new Pagina1Fragment());

        bto_navigation.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

                Fragment selectedFragment = null;

                int itemId = menuItem.getItemId();

                if (itemId == R.id.nav_home){
                    selectedFragment = new Pagina1Fragment();
                } else if (itemId == R.id.nav_search) {
                    selectedFragment = new Pagina2Fragment();
                }

                if (selectedFragment != null){
                    loadFragment(selectedFragment);
                    return true;
                }

                return false;
            }
        });

    }

    private void loadFragment(Fragment selectedFragment) {
        getSupportFragmentManager().beginTransaction().replace(R.id.frm_container,selectedFragment)
                .commit();
    }
}